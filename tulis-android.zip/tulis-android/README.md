# Tulis (APK)
Editor dokumen ringan untuk Android 5+ / RAM 2 GB.
Push ke GitHub, buka tab Actions, jalankan "Build APK", unduh artifact Tulis-APK.
