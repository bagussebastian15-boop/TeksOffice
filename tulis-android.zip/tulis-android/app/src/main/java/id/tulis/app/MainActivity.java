package id.tulis.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMinimumFontSize(1);
        s.setMinimumLogicalFontSize(1);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    startActivityForResult(p.createIntent(), 1);
                } catch (ActivityNotFoundException e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void print(final String size) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        PrintAttributes.MediaSize m;
                        if ("F4".equals(size)) m = new PrintAttributes.MediaSize("F4", "F4", 8465, 12992);
                        else if ("A5".equals(size)) m = PrintAttributes.MediaSize.ISO_A5;
                        else if ("Letter".equals(size)) m = PrintAttributes.MediaSize.NA_LETTER;
                        else if ("Legal".equals(size)) m = PrintAttributes.MediaSize.NA_LEGAL;
                        else m = PrintAttributes.MediaSize.ISO_A4;
                        PrintAttributes a = new PrintAttributes.Builder()
                            .setMediaSize(m)
                            .setMinMargins(new PrintAttributes.Margins(750, 750, 750, 750))
                            .build();
                        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                        pm.print("Tulis", web.createPrintDocumentAdapter("Tulis"), a);
                    }
                });
            }
        }, "Android");
        web.loadUrl("file:///android_asset/tulis.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("window.dispatchEvent(new Event('input'))", null);
    }
}
